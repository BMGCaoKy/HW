Define.CONNECTION={}
Define.CONNECTION.CFG={
    PLAYER=Entity.GetCfg("myplugin/player1"),
}
Define.CONNECTION.EVENT={
    
}