Define.MATCH.MAP_POS={
    ["map001"]={
        Lib.v3(0,0,0),
    }

}